import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/navbar';
import Footer from './components/Footer';
import Catalog from './components/catalog';
import About from './components/about';



function App() {
  return (
    <div className="App">
      <Navbar></Navbar>
      <p>Welcome here</p>
      <Catalog></Catalog>
      <About></About>
    </div>
  );
}

export default App;
